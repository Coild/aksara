package com.irwan.irwanta;

public class Response {
    private String[] prob;

    private String classnya;

    public String[] getProb ()
    {
        return prob;
    }

    public void setProb (String[] prob)
    {
        this.prob = prob;
    }

    public String getClassnya ()
    {
        return classnya;
    }

    public void setClassnya (String classnya)
    {
        this.classnya = classnya;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [prob = "+prob+", classnya = "+classnya+"]";
    }
}